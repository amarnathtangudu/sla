package com.dell.it.uip.prismoslascheduler;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.dell.it.uip.prismoslascheduler.model.POAck;
import com.dell.it.uip.prismoslascheduler.model.PoEventPayload;
import com.dell.it.uip.prismoslascheduler.model.SLAMasterData;
import com.dell.it.uip.prismoslascheduler.repository.POEventPayloadRepo;
import com.dell.it.uip.prismoslascheduler.repository.PoAckRepo;
import com.dell.it.uip.prismoslascheduler.repository.SLAMasterDataRepo;

import lombok.NoArgsConstructor;

@Component
@NoArgsConstructor
public class Util {

	private static long ONE_MINUTE_IN_MILLIS = 60000;

	@Autowired
	PoAckRepo poAckRepo;

	@Autowired
	POEventPayloadRepo poEventPayloadRepo;

	@Autowired
	SLAMasterDataRepo slaMasterDataRepo;

	@Scheduled(cron = "${cron.expression}")
	public void cronJobSch() throws ParseException {
		Calendar c = Calendar.getInstance(TimeZone.getTimeZone("CST"));
		long t = c.getTimeInMillis();
		Date fromDate = new Date(t - (6000 * ONE_MINUTE_IN_MILLIS));
		List<POAck> l = poAckRepo.getPoAckData(fromDate);
		HashMap<String, List<POAck>> m = new HashMap<>();
		for (int i = 0; i < l.size(); i++) {
			POAck poAck = l.get(i);
			if (m.keySet().contains(poAck.getEventId())) {
				m.get(poAck.getEventId()).add(poAck);
			} else {
				List<POAck> a = new ArrayList<>();
				a.add(poAck);
				m.put(poAck.getEventId(), a);
			}
		}
		HashMap<String, HashMap<String, Long>> timeMap = new HashMap<>();
		for (Entry<String, List<POAck>> entry : m.entrySet()) {
			String eventId = entry.getKey();
			if (eventId != null) {
				List<POAck> a = entry.getValue();
				for (int i = 0; i < a.size(); i++) {
					PoEventPayload poEventPayloadModel = poEventPayloadRepo.findLatestEvent(eventId,
							a.get(i).getCreatedDate());
					Date start = poEventPayloadModel.getCreatedDate();
					if (timeMap.keySet().contains(eventId)) {
						HashMap<String, Long> curr = timeMap.get(eventId);
						Date end = a.get(i).getCreatedDate();
						long diff = end.getTime() - start.getTime();
						if (diff < 0) {
							System.out.println(diff);
						}
						curr.put(a.get(i).getPoNumber(), diff);
					} else {
						HashMap<String, Long> n = new HashMap<>();
						Date end = a.get(i).getCreatedDate();
						long diff = end.getTime() - start.getTime();
						n.put(a.get(i).getPoNumber(), diff);
						timeMap.put(eventId, n);
					}
				}
			}
		}

		for (Entry<String, HashMap<String, Long>> entry : timeMap.entrySet()) {
			String eventId = entry.getKey();
			HashMap<String, Long> tm = entry.getValue();
			SLAMasterData slaMasterData = slaMasterDataRepo.getSlaMasterData(eventId);
			if (slaMasterData != null) {
				Map<String, Long> curr = slaMasterData.getAdditionalData();
				for (Entry<String, Long> e : tm.entrySet()) {
					if (!curr.keySet().contains(e.getKey())) {
						curr.put(e.getKey(), e.getValue());
					}
				}
				slaMasterData.setLastUpdatedDate(new Date());
			} else {
				slaMasterData = new SLAMasterData();
				Map<String, Long> n = new HashMap<String, Long>();
				for (Entry<String, Long> e : tm.entrySet()) {
					n.put(e.getKey(), e.getValue());
				}
				slaMasterData.setAdditionalData(n);
				slaMasterData.setDocId(eventId);
				slaMasterData.setDocType("Event Id");
				slaMasterData.setCreatedDate(new Date());
				slaMasterData.setSlaName("PO Creation and Approval");
			}
			slaMasterData.setAverageProcessingTime(calculateAverageSLA(slaMasterData.getAdditionalData()));
			slaMasterDataRepo.save(slaMasterData);
		}
	}

	private long calculateAverageSLA(Map<String, Long> docs) {
		long totalTime = 0l;
		for (Entry<String, Long> e : docs.entrySet()) {
			totalTime += e.getValue();
		}
		return totalTime / docs.keySet().size();
	}

}
