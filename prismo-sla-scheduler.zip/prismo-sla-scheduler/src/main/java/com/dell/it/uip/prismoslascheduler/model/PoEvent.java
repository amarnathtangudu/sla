package com.dell.it.uip.prismoslascheduler.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@AllArgsConstructor
@Document(collection = "prcPoEventXxepo006")
public class PoEvent {
	@Id
	private String _id;
	private String eventId;
	private String poNumber;
	private double revisionNum;
	private Date lastUpdateDate;
	private Date createdDate;
	private Date modifiedDate;
	private String poStatus;
}