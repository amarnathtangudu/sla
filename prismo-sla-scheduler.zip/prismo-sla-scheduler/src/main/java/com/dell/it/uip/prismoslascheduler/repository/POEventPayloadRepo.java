package com.dell.it.uip.prismoslascheduler.repository;


import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.dell.it.uip.prismoslascheduler.model.PoEventPayload;

@Repository
public class POEventPayloadRepo {

	@Autowired
	private MongoTemplate mongoTemplate;

	public PoEventPayload findLatestEvent(String eventId, Date createdDate) {
		Query query = new Query();
		query.addCriteria(Criteria.where("eventId").is(eventId));
		query.addCriteria(Criteria.where("createdDate").lt(createdDate));
		query.with(Sort.by(Sort.Direction.DESC, "createdDate"));
		return mongoTemplate.find(query, PoEventPayload.class).get(0);
	}

}
