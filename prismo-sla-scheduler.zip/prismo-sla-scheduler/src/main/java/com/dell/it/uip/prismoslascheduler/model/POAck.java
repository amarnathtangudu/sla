package com.dell.it.uip.prismoslascheduler.model;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "prcPoAckXxepo006")
public class POAck {
	@Id
	private String _id;
	private String eventId;
	private String poNumber;
	private Date createdDate;
	private String eventSource;
}