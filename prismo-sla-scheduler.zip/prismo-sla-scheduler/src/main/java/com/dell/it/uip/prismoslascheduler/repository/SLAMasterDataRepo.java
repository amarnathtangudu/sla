package com.dell.it.uip.prismoslascheduler.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.dell.it.uip.prismoslascheduler.model.SLAMasterData;

@Repository
public class SLAMasterDataRepo {

	@Autowired
	private MongoTemplate mongoTemplate;

	public SLAMasterData getSlaMasterData(String documentId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("docId").gt(documentId));
		query.with(Sort.by(Sort.Direction.DESC, "createdDate"));
		return mongoTemplate.findOne(query, SLAMasterData.class);
	}

	public SLAMasterData save(SLAMasterData data) {
		return mongoTemplate.save(data);
	}
}
