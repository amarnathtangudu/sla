package com.dell.it.uip.prismoslascheduler.model;

import java.util.Date;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@AllArgsConstructor
@Document(collection = "slaMasterData")
public class SLAMasterData {

	@Id
	private String _id;
	private String slaName;
	private String docId;
	private String docType;
	private long averageProcessingTime;
	private Date createdDate;
	private Date lastUpdatedDate;
	private SLAType slaType;
	private Map<String, Long> additionalData;

}
