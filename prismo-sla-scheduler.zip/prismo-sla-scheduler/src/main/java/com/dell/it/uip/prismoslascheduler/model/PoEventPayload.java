package com.dell.it.uip.prismoslascheduler.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "prcPoEventPayloadTrackXxepo003")
public class PoEventPayload {
	@Id
	private String _id;
	private String eventId;
	private Date createdDate;
	private Date modifiedDate;
	private String eventSource;
	private Object requestPayload;
	private Object responsePayload;
}