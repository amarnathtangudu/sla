package com.dell.it.uip.prismoslascheduler.model;

public enum SLAType {
	GOOD, BAD;
}
