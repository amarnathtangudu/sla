package com.dell.it.uip.prismoslascheduler.repository;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.dell.it.uip.prismoslascheduler.model.POAck;

@Repository
public class PoAckRepo {

	@Autowired
	private MongoTemplate mongoTemplate;

	public List<POAck> getPoAckData(Date fromDate) {
		Query query = new Query();
		query.addCriteria(Criteria.where("createdDate").gt(fromDate));
		query.with(Sort.by(Sort.Direction.DESC, "createdDate"));
		return mongoTemplate.find(query, POAck.class);
	}

}
