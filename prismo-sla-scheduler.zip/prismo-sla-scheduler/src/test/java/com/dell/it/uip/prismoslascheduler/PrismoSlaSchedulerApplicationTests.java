package com.dell.it.uip.prismoslascheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrismoSlaSchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
